<?php
namespace Mageplaza\HelloWorld\Model\Product;
class Price extends \Magento\Catalog\Model\Product\Type\Price
{
	
}