function add(a,b){
	return a+b;
}