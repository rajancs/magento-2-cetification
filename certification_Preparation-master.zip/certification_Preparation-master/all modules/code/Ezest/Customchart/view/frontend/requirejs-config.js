var config ={
	map:{
		'*':{
			module : 'Ezest_Customchart/js/testreq',
		}
	}
};