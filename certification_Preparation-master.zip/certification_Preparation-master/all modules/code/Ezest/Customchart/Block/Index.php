<?php
namespace Ezest\Customchart\Block;
class Index extends \Magento\Framework\View\Element\Template
{
	
}