<?php

namespace Ezest\Practice\Controller\Adminhtml\practice;

use Magento\Backend\App\Action;

class Test extends \Magento\Backend\App\Action
{
	public function execute(){
		 echo 'helooo'; exit;
	}
}