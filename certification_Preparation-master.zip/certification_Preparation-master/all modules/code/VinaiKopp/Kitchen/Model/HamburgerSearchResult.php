<?php
 
namespace VinaiKopp\Kitchen\Model;
 
use Magento\Framework\Api\SearchResults;
use VinaiKopp\Kitchen\Api\Data\HamburgerSearchResultInterface;
 
class HamburgerSearchResult extends SearchResults implements HamburgerSearchResultInterface
{
 
}