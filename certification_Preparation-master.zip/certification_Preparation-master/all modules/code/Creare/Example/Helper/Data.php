<?php 
namespace Creare\Example\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    public function getConfig($str)
    {
        return true;
    }
    public function getTest(){
         return true;
    }
}